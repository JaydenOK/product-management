manage BOM

composer install

GET http://product-management.cc/warehouse/bom?pageSize=&priceStart=21

POST  http://product-management.cc/warehouse/bom

PUT  http://product-management.cc/warehouse/bom?bom_id=5&name=vvvvvvvvvvvvvv&price=213324

DELETE  http://product-management.cc/warehouse/bom/3
